import os
import yt_dlp
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality
from bot.config import Config

def build_home_theatre_ffmpeg_args() -> str:
    """Builds low-latency FFmpeg filtergraph for Home Theatre Sub-Bass, Mid Clarity & Stereo Surround."""
    eq_chain = (
        f"bass=g={Config.SUB_BASS_DB}:f=65:w=0.6,"
        f"equalizer=f=1200:t=q:w=1.0:g={Config.VOCAL_MID_DB},"
        f"treble=g={Config.TREBLE_AIR_DB}:f=10000,"
        f"extrastereo=m={1.0 + float(Config.SURROUND_WIDTH)},"
        "loudnorm=I=-14:TP=-1.5:LRA=11"
    )
    return f'-vn -af "{eq_chain}" -ac 2 -ar 48000'

def song_inline_keyboard(query: str) -> InlineKeyboardMarkup:
    q_enc = query.replace(" ", "+")
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("▶ Play in VC", callback_data=f"vcplay|{query[:40]}"),
            InlineKeyboardButton("+ Add Queue", callback_data=f"vcqueue|{query[:40]}"),
        ],
        [
            InlineKeyboardButton("YouTube", url=f"https://www.youtube.com/results?search_query={q_enc}"),
            InlineKeyboardButton("Spotify", url=f"https://open.spotify.com/search/{q_enc}"),
            InlineKeyboardButton("SoundCloud", url=f"https://soundcloud.com/search?q={q_enc}"),
        ],
        [
            InlineKeyboardButton("🎛 Home Theatre", callback_data="dsp_toggle"),
            InlineKeyboardButton("🎙 Ask Girl AI", callback_data="vc_ai_prompt"),
        ],
        [
            InlineKeyboardButton(
                "➕ Add Bot to Group",
                url=f"https://t.me/{Config.BOT_USERNAME}?startgroup=true",
            )
        ],
    ])

async def resolve_stream_url(query: str) -> dict:
    ydl_opts = {
        "format": "bestaudio/best",
        "quiet": True,
        "noplaylist": True,
        "default_search": "ytsearch1",
    }
    search_target = query
    if "soundcloud.com" in query or "spotify.com" in query or "youtu" in query:
        search_target = query
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(search_target, download=False)
        if "entries" in info:
            info = info["entries"][0]
        return {
            "title": info.get("title", query),
            "url": info["url"],
            "duration": info.get("duration_string", "Live"),
            "webpage_url": info.get("webpage_url", ""),
        }

def register_music_handlers(bot: Client, call_py: PyTgCalls):
    @bot.on_message(filters.command(["song", "play", "spotify", "soundcloud"]))
    async def play_or_song_cmd(client: Client, message: Message):
        if len(message.command) < 2:
            await message.reply_photo(
                photo=Config.START_IMG_URL,
                caption=(
                    "**SwarAI Multi-Language Music & Home Theatre Engine**\n\n"
                    "Usage: `/song Kesariya` or `/play <YouTube | Spotify | SoundCloud URL>`\n"
                    f"Active DSP: `{Config.DSP_PRESET}` · 24/7 Stream: `{Config.MODE_24_7}`"
                ),
                reply_markup=song_inline_keyboard("Kesariya Acoustic"),
            )
            return

        query = " ".join(message.command[1:])
        status = await message.reply_text(f"Resolving high-bitrate stream for **{query}**...")
        track = await resolve_stream_url(query)

        if message.command[0].lower() in ["play", "spotify", "soundcloud"] and message.chat.id < 0:
            await call_py.play(
                message.chat.id,
                MediaStream(
                    track["url"],
                    audio_parameters=AudioQuality.STUDIO,
                    ffmpeg_parameters=build_home_theatre_ffmpeg_args(),
                ),
            )

        await status.delete()
        photo_source = Config.START_IMG_URL if Config.START_IMG_URL else Config.LOCAL_FALLBACK_BANNER
        await message.reply_photo(
            photo=photo_source,
            caption=(
                f"**Now Streaming in Home Theatre Mode**\n"
                f"**Track:** {track['title']}\n"
                f"**Duration:** {track['duration']} · **Codec:** 48 kHz Opus Low-Latency\n"
                f"**DSP Profile:** {Config.DSP_PRESET} (24/7 Queue Enabled)"
            ),
            reply_markup=song_inline_keyboard(track["title"]),
        )
