from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery
from bot.config import Config

def main_help_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🎵 Music & /song", callback_data="help|music"),
            InlineKeyboardButton("🎙 VC Girl AI (HI/EN)", callback_data="help|vcai"),
        ],
        [
            InlineKeyboardButton("📚 UPSC & Schemes Quiz", callback_data="help|quiz"),
            InlineKeyboardButton("🛡 Group Security", callback_data="help|security"),
        ],
        [
            InlineKeyboardButton("⚡ Troubleshooting & Scaling", callback_data="help|devops"),
        ],
        [
            InlineKeyboardButton(
                "➕ Add SwarAI Bot to Your Group",
                url=f"https://t.me/{Config.BOT_USERNAME}?startgroup=true",
            )
        ],
    ])

HELP_SECTIONS = {
    "music": "**Music & Home Theatre Commands**\n• `/song <name>` — Multi-source YouTube/Spotify/SoundCloud card\n• `/play <query>` — 48kHz Opus VC stream\n• `/hometheatre` — 5.1 Surround + 65Hz Sub-Bass\n• `/loop247` — Non-stop 24/7 radio mode",
    "vcai": "**Voice Chat Girl AI (Hindi & English)**\n• `/ai <question>` — Ask Aarohi anything; she replies in text + live VC voice\n• Supports Hindi, English & Hinglish with automatic background music ducking.",
    "quiz": "**UPSC, Schemes & All-Exam Quiz**\n• `/upsc` — GS Prelims MCQ Poll\n• `/schemes` — Central Govt Yojanas & Ministries\n• `/currentaffairs` — Daily PIB & Current Affairs\n• `/examquiz` — SSC, Banking & Railways",
    "security": "**High-Level Group Security**\n• `/antiflood on` — Sliding-window rate limiter\n• `/antilink strict` — Invite link & bio spam shield\n• `/captcha button` — New member verification\n• `/lockdown` — Emergency anti-raid shield",
    "devops": "**Troubleshooting & Auto-Scaling**\n• Ensure Assistant has `Manage Voice Chats` right.\n• FFmpeg 6 handles zero-buffering Opus framing.\n• Kubernetes HPA scales pods automatically on traffic spikes.",
}

def register_help_handlers(bot: Client):
    @bot.on_message(filters.command(["start", "help"]))
    async def start_and_help(client: Client, message: Message):
        await message.reply_photo(
            photo=Config.START_IMG_URL,
            caption=(
                "**SwarAI — 24/7 Home Theatre Music, VC Girl AI & UPSC Quiz Bot**\n\n"
                "Select any module button below for quick commands, live VC controls, and troubleshooting:"
            ),
            reply_markup=main_help_keyboard(),
        )

    @bot.on_callback_query(filters.regex(r"^help\|"))
    async def navigate_help_section(client: Client, query: CallbackQuery):
        section = query.data.split("|")[1]
        text = HELP_SECTIONS.get(section, "Select a help category below:")
        await query.message.edit_caption(caption=text, reply_markup=main_help_keyboard())
