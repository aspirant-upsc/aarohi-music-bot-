import json
from google import genai
from google.genai import types
from pyrogram import Client, filters
from pyrogram.enums import PollType
from pyrogram.types import Message
from bot.config import Config

ai_client = genai.Client(api_key=Config.GEMINI_API_KEY)

def register_quiz_handlers(bot: Client):
    @bot.on_message(filters.command(["upsc", "schemes", "currentaffairs", "examquiz"]))
    async def launch_exam_quiz(client: Client, message: Message):
        cmd = message.command[0].lower()
        topic = " ".join(message.command[1:]) or (
            "Indian Central Government Schemes & Nodal Ministries"
            if cmd == "schemes"
            else "UPSC CSE Prelims Current Affairs & Polity"
        )

        resp = ai_client.models.generate_content(
            model="gemini-3.8-flash",
            contents=(
                f"Create 1 exam-standard bilingual (English + Hindi) MCQ on {topic}. "
                "Return JSON with question (max 280 chars), 4 options (max 95 chars each), "
                "correct_index (0-3), and explanation (max 190 chars)."
            ),
            config=types.GenerateContentConfig(response_mime_type="application/json"),
        )
        q = json.loads(resp.text)

        await client.send_poll(
            chat_id=message.chat.id,
            question=q["question"][:295],
            options=[opt[:98] for opt in q["options"][:4]],
            type=PollType.QUIZ,
            correct_option_id=int(q["correct_index"]),
            explanation=q["explanation"][:195],
            is_anonymous=False,
            open_period=45,
        )
