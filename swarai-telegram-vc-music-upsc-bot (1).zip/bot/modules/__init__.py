from pyrogram import Client
from pytgcalls import PyTgCalls
from bot.modules.music import register_music_handlers
from bot.modules.vc_ai_girl import register_vc_ai_handlers
from bot.modules.quiz_upsc import register_quiz_handlers
from bot.modules.security import register_security_handlers
from bot.modules.help_buttons import register_help_handlers

def register_all_handlers(bot: Client, call_py: PyTgCalls):
    register_help_handlers(bot)
    register_music_handlers(bot, call_py)
    register_vc_ai_handlers(bot, call_py)
    register_quiz_handlers(bot)
    register_security_handlers(bot)
