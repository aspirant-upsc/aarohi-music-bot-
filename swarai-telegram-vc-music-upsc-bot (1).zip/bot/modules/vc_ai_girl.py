import base64
import tempfile
from google import genai
from google.genai import types
from pyrogram import Client, filters
from pyrogram.types import Message
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream, AudioQuality
from bot.config import Config

ai_client = genai.Client(api_key=Config.GEMINI_API_KEY)

SYSTEM_PROMPT = (
    "You are Aarohi, an articulate, warm female Voice Chat AI host and UPSC/exam mentor "
    "in a Telegram Group Voice Chat. Every group member can ask you questions in Hindi or English. "
    "Reply naturally in Hindi, English, or Bilingual (Hindi + English) matching their request, "
    "keeping answers concise (2-4 spoken sentences) for smooth Voice Chat playback."
)

async def ask_aarohi_and_synthesize(member_name: str, question: str) -> tuple[str, str | None]:
    text_resp = ai_client.models.generate_content(
        model="gemini-3.8-flash",
        contents=f"{member_name} asks in Telegram VC: {question}",
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            tools=[types.Tool(google_search=types.GoogleSearch())],
        ),
    )
    answer_text = (text_resp.text or "").strip()

    tts_resp = ai_client.models.generate_content(
        model="gemini-3.8-flash-lite-tts",
        contents=answer_text,
        config=types.GenerateContentConfig(
            response_modalities=["AUDIO"],
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=Config.VC_AI_VOICE)
                )
            ),
        ),
    )

    wav_path = None
    for part in tts_resp.candidates[0].content.parts:
        if part.inline_data and part.inline_data.data:
            fd, wav_path = tempfile.mkstemp(suffix=".wav")
            with open(fd, "wb") as f:
                f.write(part.inline_data.data)
            break

    return answer_text, wav_path

def register_vc_ai_handlers(bot: Client, call_py: PyTgCalls):
    @bot.on_message(filters.command(["ai", "vcai", "ask"]))
    async def handle_vc_ai_question(client: Client, message: Message):
        if len(message.command) < 2:
            await message.reply_text(
                "Ask Aarohi (VC Girl AI) anything in Hindi or English:\n"
                "Example: `/ai पीएम विश्वकर्मा योजना क्या है?` or `/ai Explain Repo Rate vs SDF`"
            )
            return

        member = message.from_user.first_name if message.from_user else "Member"
        question = " ".join(message.command[1:])
        thinking = await message.reply_text(f"🎙 **Aarohi** is answering **{member}** in VC...")

        answer_text, wav_path = await ask_aarohi_and_synthesize(member, question)
        await thinking.edit_text(f"🎙 **Aarohi (VC Girl AI → {member}):**\n\n{answer_text}")

        if wav_path:
            if message.chat.id < 0:
                await call_py.play(
                    message.chat.id,
                    MediaStream(wav_path, audio_parameters=AudioQuality.HIGH),
                )
            else:
                await message.reply_voice(wav_path, caption="Aarohi Bilingual Voice Reply")
