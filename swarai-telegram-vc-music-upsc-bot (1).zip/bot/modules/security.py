import time
import re
from collections import defaultdict
from pyrogram import Client, filters
from pyrogram.types import (
    ChatPermissions,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    Message,
    CallbackQuery,
)

FLOOD_TRACKER: dict[tuple[int, int], list[float]] = defaultdict(list)
INVITE_REGEX = re.compile(r"(https?://)?(t\.me|telegram\.me)/(\+|joinchat/)[a-zA-Z0-9_-]+", re.I)

def register_security_handlers(bot: Client):
    @bot.on_message(filters.new_chat_members)
    async def verify_new_members(client: Client, message: Message):
        for user in message.new_chat_members:
            if user.is_bot:
                continue
            await client.restrict_chat_member(
                message.chat.id,
                user.id,
                ChatPermissions(can_send_messages=False),
            )
            await message.reply_text(
                f"Welcome {user.mention}! Tap below within 90 seconds to verify and join VC & Quiz.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Verify Human Access", callback_data=f"verify|{user.id}")
                ]]),
            )

    @bot.on_callback_query(filters.regex(r"^verify\|"))
    async def complete_captcha(client: Client, query: CallbackQuery):
        target_uid = int(query.data.split("|")[1])
        if query.from_user.id != target_uid:
            await query.answer("This verification button is only for the newly joined member.", show_alert=True)
            return
        await client.restrict_chat_member(
            query.message.chat.id,
            target_uid,
            ChatPermissions(can_send_messages=True, can_send_media_messages=True),
        )
        await query.message.edit_text(f"✅ {query.from_user.mention} verified! Enjoy Music, VC AI & UPSC Quizzes.")

    @bot.on_message(filters.group & filters.text & ~filters.command(["start", "help", "song", "play", "ai", "upsc"]))
    async def group_shield_guard(client: Client, message: Message):
        if not message.from_user:
            return
        key = (message.chat.id, message.from_user.id)
        now = time.time()
        FLOOD_TRACKER[key] = [t for t in FLOOD_TRACKER[key] if now - t < 4.0]
        FLOOD_TRACKER[key].append(now)

        if len(FLOOD_TRACKER[key]) > 6:
            await message.delete()
            await client.restrict_chat_member(message.chat.id, message.from_user.id, ChatPermissions())
            await message.reply_text(f"🛡 Flood detected: {message.from_user.mention} muted temporarily.")
            return

        if INVITE_REGEX.search(message.text or ""):
            await message.delete()
            await message.reply_text(f"🛡 External invite links are blocked ({message.from_user.mention}).")
