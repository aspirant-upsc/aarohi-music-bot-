import asyncio
import logging
from pyrogram import Client, idle
from pytgcalls import PyTgCalls
from bot.config import Config
from bot.modules import register_all_handlers
from bot.metrics import start_metrics_server

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("SwarAI")

bot = Client(
    "SwarAIBot",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    bot_token=Config.BOT_TOKEN,
)

assistant = Client(
    "SwarAIAssistant",
    api_id=Config.API_ID,
    api_hash=Config.API_HASH,
    session_string=Config.ASSISTANT_SESSION,
)

call_py = PyTgCalls(assistant, cache_duration=100)

async def main():
    start_metrics_server(Config.METRICS_PORT)
    await bot.start()
    await assistant.start()
    await call_py.start()
    register_all_handlers(bot, call_py)
    logger.info("SwarAI Music, VC Girl AI, Security & UPSC Bot is live 24/7.")
    await idle()
    await bot.stop()
    await assistant.stop()

if __name__ == "__main__":
    asyncio.get_event_loop().run_until_complete(main())
