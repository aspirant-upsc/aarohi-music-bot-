import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    API_ID = int(os.getenv("API_ID", "123456"))
    API_HASH = os.getenv("API_HASH", "")
    BOT_TOKEN = os.getenv("BOT_TOKEN", "")
    BOT_USERNAME = os.getenv("BOT_USERNAME", "SwarAIVCBot")
    ASSISTANT_SESSION = os.getenv("ASSISTANT_SESSION", "")

    # Gemini AI for Bilingual (Hindi + English) Girl AI VC Host & Dynamic UPSC Quiz
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    VC_AI_VOICE = os.getenv("VC_AI_VOICE", "Kore")

    # Multi-Platform Resolver Credentials (Optional for Spotify direct API, yt-dlp handles YouTube & SoundCloud)
    SPOTIFY_CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID", "")
    SPOTIFY_CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET", "")

    # Welcome & /song Card Banner (LBSNAA Aspirant Theme + Local Fallback)
    START_IMG_URL = os.getenv(
        "START_IMG_URL",
        "https://i.pinimg.com/736x/fd/4d/0a/fd4d0a3861e88b470c2410706c8c2e7a.jpg"
    )
    LOCAL_FALLBACK_BANNER = "assets/lbsnaa_start_banner.jpg"

    # Home Theatre FFmpeg Audio DSP Defaults (Synced from Studio)
    DSP_PRESET = "Dolby Home Theatre"
    SUB_BASS_DB = 6
    VOCAL_MID_DB = 2.5
    TREBLE_AIR_DB = 4
    SURROUND_WIDTH = 0.62
    MODE_24_7 = True

    # Redis & Prometheus Metrics for Auto-Scaling Cluster
    REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
    METRICS_PORT = int(os.getenv("METRICS_PORT", "9090"))
    ACTIVE_SECURITY_MODULES = "sec-flood, sec-links, sec-captcha, sec-profanity"
