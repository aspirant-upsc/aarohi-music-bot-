from http.server import BaseHTTPRequestHandler, HTTPServer
import threading

ACTIVE_VC_STREAMS = 0

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/metrics":
            payload = (
                "# HELP swarai_active_vc_streams Active Telegram Voice Chat streams\n"
                "# TYPE swarai_active_vc_streams gauge\n"
                f"swarai_active_vc_streams {ACTIVE_VC_STREAMS}\n"
            ).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; version=0.0.4")
            self.end_headers()
            self.wfile.write(payload)
        else:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK")

    def log_message(self, format, *args):
        return

def start_metrics_server(port: int = 9090):
    server = HTTPServer(("0.0.0.0", port), MetricsHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
