# SwarAI — 24/7 Telegram Music, VC Girl AI (Hindi/English), Group Security & UPSC Quiz Bot

## Key Capabilities
- **Voice Chat Girl AI (Aarohi)**: All group members can ask questions in **Hindi or English** via `/ai` or voice; replies with Gemini `gemini-3.8-flash` + `gemini-3.8-flash-lite-tts` (`Kore` voice) with smooth background music auto-ducking.
- **Multi-Language Smooth Music (`/song` & `/play`)**: Streams YouTube, Spotify, and SoundCloud in 48 kHz Opus with real-time FFmpeg **Home Theatre 5.1 Surround & Sub-Bass DSP** and 24/7 loop mode.
- **UPSC, Current Affairs, Schemes & All-Exam Quiz**: Native timed Telegram Quiz Polls via `/upsc`, `/schemes`, `/currentaffairs`, and `/examquiz`.
- **High-Level Group Security**: Sliding-window anti-flood, `t.me` invite link blocker, inline human verification captcha, and emergency raid lockdown.
- **GitHub CI/CD & HPA Auto-Scaling**: Includes `Dockerfile`, `docker-compose.yml`, `deploy/k8s-hpa.yaml`, and `tests/load_test.py`.

## Quick Deployment (Docker / Any Linux VPS)
```bash
cp .env.example .env
# Fill API_ID, API_HASH, BOT_TOKEN, ASSISTANT_SESSION, GEMINI_API_KEY in .env
docker compose up -d --build
```

## Kubernetes Auto-Scaling Deployment
```bash
kubectl apply -f deploy/k8s-hpa.yaml
```
